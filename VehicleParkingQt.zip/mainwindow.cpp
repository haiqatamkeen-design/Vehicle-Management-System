#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMessageBox>
#include <QString>

Vehicle parking[MAX_VEHICLES];
int count = 0;

int getHourlyRate(int type) {
    if(type == 1) return 20;
    if(type == 2) return 50;
    if(type == 3) return 100;
    return 0;
}

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->comboVehicleType->addItem("Bike");
    ui->comboVehicleType->addItem("Car");
    ui->comboVehicleType->addItem("Truck");
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_btnPark_clicked()
{
    if(count >= MAX_VEHICLES) {
        QMessageBox::warning(this,"Parking Full","No more parking slots available!");
        return;
    }

    Vehicle &v = parking[count];
    v.vehicleNo = ui->txtVehicleNo->text().toInt();
    v.vehicleType = ui->comboVehicleType->currentIndex() + 1;
    v.hours = ui->txtHours->text().toInt();
    v.date.day = ui->txtDay->text().toInt();
    v.date.month = ui->txtMonth->text().toInt();
    v.date.year = ui->txtYear->text().toInt();
    v.time.hour = ui->txtHour->text().toInt();
    v.time.minute = ui->txtMinute->text().toInt();

    v.hourlyRate = getHourlyRate(v.vehicleType);
    v.totalFee = v.hours * v.hourlyRate;

    QMessageBox::information(this,"Parked",QString("Vehicle parked! Total fee: %1").arg(v.totalFee));
    count++;
}

void MainWindow::on_btnRemove_clicked()
{
    int vno = ui->txtVehicleNo->text().toInt();
    for(int i=0;i<count;i++) {
        if(parking[i].vehicleNo == vno) {
            for(int j=i;j<count-1;j++) parking[j] = parking[j+1];
            count--;
            QMessageBox::information(this,"Removed","Vehicle removed successfully!");
            return;
        }
    }
    QMessageBox::warning(this,"Not Found","Vehicle not found!");
}

void MainWindow::on_btnDisplay_clicked()
{
    ui->listVehicles->clear();
    for(int i=0;i<count;i++) {
        QString type = (parking[i].vehicleType==1)?"Bike":(parking[i].vehicleType==2)?"Car":"Truck";
        QString item = QString("%1 | %2 | %3h | Fee: %4 | %5/%6/%7 %8:%9")
                .arg(parking[i].vehicleNo)
                .arg(type)
                .arg(parking[i].hours)
                .arg(parking[i].totalFee)
                .arg(parking[i].date.day)
                .arg(parking[i].date.month)
                .arg(parking[i].date.year)
                .arg(parking[i].time.hour)
                .arg(parking[i].time.minute);
        ui->listVehicles->addItem(item);
    }
}
