#pragma once

struct Date {
    int day, month, year;
};

struct Time {
    int hour, minute;
};

struct Vehicle {
    int vehicleNo;
    int vehicleType; // 1-Bike, 2-Car, 3-Truck
    int hours;
    int hourlyRate;
    int totalFee;
    Date date;
    Time time;
};

const int MAX_VEHICLES = 10;
extern Vehicle parking[MAX_VEHICLES];
extern int count;

int getHourlyRate(int type);
