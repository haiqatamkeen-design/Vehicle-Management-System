# Vehicle Parking Management System (Qt GUI)

## Team Details
**Team Name:** Parking Wizards  
**Team ID:** PW123  

**Team Members:**
- Alice Smith – ID: 1001
- Bob Johnson – ID: 1002

## Project Description
A Vehicle Parking Management System with GUI using Qt Widgets.
Features:
- Park vehicles (Bike, Car, Truck)
- Remove vehicles
- Display all parked vehicles
- Calculate total fees

## Tools/Technologies Used
- Qt 5/6 Widgets
- C++
- Qt Creator or Visual Studio with Qt Plugin
